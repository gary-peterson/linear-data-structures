

public interface Iterator {
	public Object next();
	public Object peek();
	public boolean hasNext();
}