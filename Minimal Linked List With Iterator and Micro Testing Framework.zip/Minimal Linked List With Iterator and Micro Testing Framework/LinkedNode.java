

public class LinkedNode {
	
	// ==========================================
	// Ivars
	
	private Object data;
	private LinkedNode nextNode;
	
	// ------------------------------------------
	// Constructors		

	public LinkedNode(Object newData) {
		this.setData(newData);
	}
	
	// ------------------------------------------
	// Accessors		

	public Object setData(Object aData) {
		return data = aData;
	}

	public Object getData() {
		return data;
	}
	
	public void setNextNode(LinkedNode aNextNode) {
		nextNode = aNextNode;
	}	

	public LinkedNode getNextNode() {
		return nextNode;
	}
	
	public void clearLinks() {
		this.nextNode = null;
	}

}