
//Functional interface for zero arg no return closure

@FunctionalInterface
interface Procedure {
  void evaluate();
}