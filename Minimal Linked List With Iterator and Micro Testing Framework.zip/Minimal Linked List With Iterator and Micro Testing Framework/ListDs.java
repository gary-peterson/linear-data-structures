

import java.util.List;
@SuppressWarnings("rawtypes") //Not using generics

public interface ListDs {
	
	public void addFirst(Object data);
	public void addLast(Object data);	
	public Object removeFirst();
	public Object removeLast();	
	public Object first();	
	public Object last();
	
	public Iterator toIterator();
	public List asList();
	public boolean isEmpty();
	public void displayAll();	

}
