
import java.util.ArrayList;
import java.util.List;

/*We implement the ListDs interface that specs out "core" data structure list behavior
If desired, the "implements" could be removed if desired. Or, optionally, an ArrayedList 
could also implement "Listds" to provide a general protocal for linked or arrayed lists*/

@SuppressWarnings("rawtypes") //Not using generics

public class LinkedList implements ListDs {
	
	private LinkedNode firstNode;
	private LinkedNode lastNode;	

	@Override
	public void addFirst(Object data) {
		//Add data to front of list
		this.addFirstNode(this.newNode(data));
	}

	@Override
	public void addLast(Object data) {
		//Add data to end of list		
		this.addLastNode(this.newNode(data));
	}

	@Override
	public Object removeFirst() {
		//Remove first node (and return "data" it contains)
		return getDataFromNode(this.removeFirstNode());
	}

	@Override
	public Object removeLast() {
		//Remove last node (and return "data" it contains)		
		return getDataFromNode(this.removeLastNode());
	}
	
	public int size() {
		Iterator iter = this.toIterator();
		int count=0;
		while (iter.hasNext()) {
			count++;
			iter.next();
		}
		return count;
	}

	@Override
	public Object first() {
		//Return the "data" in our first node
		return this.coerceData(this.firstNode);
	}

	@Override
	public Object last() {
		//Return the "data" in our last node
		return this.coerceData(this.lastNode);
	}

	@Override
	public Iterator toIterator() {
		return new NodeIterator(this.firstNode);
	}
		
	@SuppressWarnings("unchecked") //"add" okay	
	@Override
	public List asList() {
		//Return a list containing our data
		List newList = new ArrayList();
		Iterator iter = this.toIterator();
		while (iter.hasNext())
			newList.add(iter.next());
		return newList;
	}

	@Override
	public boolean isEmpty() {
		return this.firstNode == null;
	}

	@Override
	public void displayAll() {
		Iterator iter = this.toIterator();
		while (iter.hasNext())
			println(iter.next());
	}
	
	//=======================================================
	//Helpers
	
	protected void addFirstNode(LinkedNode newNode) {
		if (addNodeForEmptySpecialCase(newNode))
			return;
		newNode.setNextNode(this.firstNode);
		this.firstNode = newNode;
	} 
	
	protected void addLastNode(LinkedNode newNode) {
		if (addNodeForEmptySpecialCase(newNode))
			return;
		this.lastNode.setNextNode(newNode);
		this.lastNode = newNode;
	}	
	
	protected boolean addNodeForEmptySpecialCase(LinkedNode newNode) {
		//If we're an empty linked list, then simply set our two ivars to the newNode
		//Return true, if we added newNode (empty case), or false, if we did nothing (not-empty case)
		if (this.isEmpty()) {
			this.firstNode = newNode;
			this.lastNode = newNode;
			return true;
		}
		return false;
	}
	
	protected LinkedNode newNode(Object data) {
		return new LinkedNode(data);
	}
	
	protected LinkedNode removeFirstNode() {
		if (this.isEmpty())
			return null;
		LinkedNode oldFirstNode = this.firstNode;
		this.firstNode = this.firstNode.getNextNode();
		oldFirstNode.clearLinks();
		return oldFirstNode;
	}
	
	protected LinkedNode removeLastNode() {
		if (this.isEmpty())
			return null;
		LinkedNode oldLastNode = this.lastNode;
		this.lastNode = this.getNodeBefore(oldLastNode);
		if (this.lastNode != null)
			this.lastNode.setNextNode(null);
		else
			clear();	//linked list is now empty
		oldLastNode.clearLinks();
		return oldLastNode;
	}	
	
	protected LinkedNode getNodeBefore(LinkedNode aNode) {
		NodeIterator iter = (NodeIterator)this.toIterator();
		LinkedNode previous = null;
		while (iter.hasNext())
			if (iter.getCurrentNode() == aNode)
				return previous;
			else {
				previous = iter.getCurrentNode();
				iter.next();
			}
		return previous;
	}
	
	protected Object coerceData(LinkedNode n) {
		//Return data fron node (null-guard)
		if (n == null)
			return null;
		else
			return n.getData();
	}
	
	public Object getDataFromNode(LinkedNode n) {
		if (n == null)
			return null;
		else
			return n.getData();
	}
	
	protected void clear() {
		//Clear this linked list by setting firstNode and lastNode to null
		//A little cleanup first
		if (this.firstNode != null)
			this.firstNode.clearLinks();
		if (this.lastNode != null)
			this.lastNode.clearLinks();
		//Now clear
		this.firstNode = null;
		this.lastNode = null;
	}	
	
	public static void println(Object o) {
		System.out.println(o.toString());
	}
		
}
