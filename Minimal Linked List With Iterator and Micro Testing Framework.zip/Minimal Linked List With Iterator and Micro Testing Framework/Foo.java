

public class Foo {

}