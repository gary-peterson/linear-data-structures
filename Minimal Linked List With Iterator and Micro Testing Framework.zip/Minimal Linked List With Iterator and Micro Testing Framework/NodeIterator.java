

public class NodeIterator extends AbstractIterator {
		
	private LinkedNode currentNode;
	
	//Constructor
	public NodeIterator(LinkedNode newCurrentNode) {
		this.currentNode = newCurrentNode; 
	}	
	
	//Getter
	public LinkedNode getCurrentNode() {
		return currentNode;
	}

	@Override
	public boolean hasNext() {
		return this.currentNode != null;
	}

	@Override
	public void basicMoveToNext() {
		this.currentNode = this.currentNode.getNextNode();
	}

	@Override
	public Object basicPeek() {
		return this.currentNode.getData();
	}

}
