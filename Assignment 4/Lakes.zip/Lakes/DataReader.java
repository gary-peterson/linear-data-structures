
import java.util.List;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.charset.Charset;
import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;
import java.util.ArrayList;

public class DataReader
{
	private String path, delimiter;
	private List<List<String>> rows;

	public List<List<String>> getRows() { return rows; }

	public DataReader(String aPath, String aDelimiter)
	{
		path = aPath;
		delimiter = aDelimiter;
		rows = new ArrayList<List<String>>();
	}

	public String[] trimAll(String[] strings)
	{
		//Trim strings by collecting and trimming each
		Stream<String>
			strm = Arrays.stream(strings),
			outputStrm;
		outputStrm = strm.map(each -> each.trim());
		return outputStrm.toArray(String[]::new);
	}

	public List<String> parseLine(String line)
	{
		//-1 means preserve last if blank
		String[] values = line.split(delimiter, -1);
		String[] trimmedStrings = trimAll(values);
		return Arrays.asList(trimmedStrings);
	}

	public void parseLines(List<String> lines)
	{
		for (String eachLine: lines)
			rows.add(parseLine(eachLine));
	}

	public List<String> readLines(String path)
	{
		List<String> lines = null;
		try { lines = Files.readAllLines(Paths.get(path),Charset.defaultCharset()); }
		catch (IOException exeption)
		{
			System.out.println("IO exception for -- " + path);
			System.out.println(exeption.getMessage());
		}
		return lines;
	}

	public void read()
	{
		parseLines(readLines(path));
	}




}







