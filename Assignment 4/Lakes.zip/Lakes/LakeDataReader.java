
import java.util.*;

public class LakeDataReader
{
	private String fileName;
	private String fieldDelimiter;

	public LakeDataReader(String aFileName, String aFieldDelimiter)
	{
		this.fileName = aFileName;
		this.fieldDelimiter = aFieldDelimiter;
	}

	public List<Lake> readLakes()
	{
		//Read lake data
		DataReader lakeDataReader = new DataReader(this.fileName, this.fieldDelimiter);
		lakeDataReader.read();
		List<Lake> lakes = new ArrayList<Lake>();
		for (List<String> eachRow: lakeDataReader.getRows())
		{
			Lake lk = this.newLake(eachRow);
			if (lk != null)
				lakes.add(this.newLake(eachRow));
		}
		return lakes;
	}

	public Lake newLake(List<String> fields)
	{
		//Return new Lake or null (on error)

		//gpImprove -- need to throw/handle exception
		if (fields.size() != 7)
		{
			System.out.println("Expecting 7 Fields: " + Arrays.toString(fields.toArray()));
			return null;
		}

		//Fields are:
		//name, county, nearbyTown, size, littoralZone*, maxDepth, clarity
		//We do not use littoralZone (index=4)
		//Ignore any records with incomplete data
		for (int index=3; index<=6; index++) {
			String eachFieldValue = fields.get(index).trim();
			if (eachFieldValue.isEmpty() || !this.validateNumberString(eachFieldValue))
				return null;
		}

		String name = fields.get(0);
		String county = fields.get(1);
		String nearbyTown = fields.get(2);
		//some values have decimal, so need to use Double type to parse
		int size, maxDepth, clarity;
		String next;

		next = fields.get(3);
		size = next.equalsIgnoreCase("N/A") ? -1 : (int)Math.round(Double.valueOf(next));

		//ignore field 4 by design

		next = fields.get(5);
		maxDepth = next.equalsIgnoreCase("N/A") ? -1 : (int)Math.round(Double.valueOf(next));

		next = fields.get(6);
		clarity = next.equalsIgnoreCase("N/A") ? -1 : (int)Math.round(Double.valueOf(next));

		return new Lake(name, county, nearbyTown, size, maxDepth, clarity);
	}


	public boolean validateNumberString(String numberString)
	{
		//We allow "N/A"
		if (numberString.equalsIgnoreCase("N/A"))
			return true;
		try { Double.valueOf(numberString); }
		catch(Exception e) {
			System.out.println("EXCEPTION: " + e.toString());
			return false; }
		return true;
	}


}





