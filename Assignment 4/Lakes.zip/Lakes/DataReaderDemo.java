
import java.util.*;
import static java.lang.System.out;

public class DataReaderDemo
{

	public static void main(String[] args) {
		DataReaderDemo demo = new DataReaderDemo();
		demo.demoReadingLakes();
	}

	public void demoReadingLakes() {

		LakeDataReader reader = new LakeDataReader("MinnesotaLakes.csv", ",");
		List<Lake> lakes = reader.readLakes();
		out.println("Number of Lakes: " + lakes.size());
		for (Lake eachLake: lakes)
			out.println(eachLake);
	}

}





