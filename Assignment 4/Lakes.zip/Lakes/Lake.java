
public class Lake
{
	private String name;
	private String county;
	private String nearbyTown;
	private int size;				//acres
	private int maxDepth;			//feet
	private int clarity;			//feet (visibility)

	public Lake(String aName, String aCounty, String aNearbyTown, int aSize, int aMaxDepth, int aClarity)
	{
		this.name = aName;
		this.county = aCounty;
		this.nearbyTown = aNearbyTown;
		this.size = aSize;
		this.maxDepth = aMaxDepth;
		this.clarity = aClarity;
	}

	public String toString()
	{
		String sz, depth, clarity;
		sz = String.format("%,d", this.size);
		depth = String.format("%d", this.maxDepth);
		clarity = String.format("%d", this.clarity);
		//clarity = String.format("%,d acres", this.size);
		return String.format("%-20s %-20s %-15s %-15s %-15s", this.name, this.county, sz, depth, clarity);
	}

	public static String fieldLabelsFormatted()
	{
		return String.format("%-20s %-20s %-15s %-15s %-15s",
								"Lake Name", "County", "Size (acres)", "Max Depth (ft)", "Clarity (ft)");
	}

	public String getName() { return name; }
	public String getCounty() { return county; }
	public String getNearbyTown() { return nearbyTown; }
	public int getSize() { return size; }
	public int getMaxDepth() { return maxDepth; }
	public int getClarity() { return clarity; }

	public boolean isFieldValid(String fieldName)
	{
		String field = fieldName.toLowerCase();
		switch(field)
		{
			case "size": return getSize() >= 0;
			case "maxdepth": return getMaxDepth() >= 0;
			case "depth": return getMaxDepth() >= 0;
			case "clarity": return getClarity() >= 0;
		}
		return false;
	}

	public boolean isBiggerThan(Lake other) { return this.getSize() > other.getSize(); }

	@Override
	public int hashCode() {
		int hashCode = 7;
		hashCode = 31 * hashCode + (this.name==null ? 0 : this.name.hashCode());
		hashCode = 31 * hashCode + (this.county==null ? 0 : this.county.hashCode());
		hashCode = 31 * hashCode + (this.nearbyTown==null ? 0 : this.nearbyTown.hashCode());
		hashCode = 31 * hashCode + this.size;
		hashCode = 31 * hashCode + this.maxDepth;
		hashCode = 31 * hashCode + this.clarity;
		return hashCode;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Lake))
			return false;
		Lake other = (Lake)o;
		return
			stringCompare(this.getName(), other.getName())
				&& stringCompare(this.getCounty(), other.getCounty())
				&& stringCompare(this.getNearbyTown(), other.getNearbyTown())
				&& this.getSize()==other.getSize()
				&& this.getMaxDepth()==other.getMaxDepth()
				&& this.getClarity()==other.getClarity();
	}

	public static boolean stringCompare(String a, String b) {
		if (a==null && b==null) return true;
		if (a==null || b==null) return false;
		return a.equals(b);
	}

}


