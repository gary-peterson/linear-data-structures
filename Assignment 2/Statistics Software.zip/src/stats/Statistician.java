package stats;

public class Statistician
{
	int[] nums;

	public int[] getNums() { return nums; }

	public Statistician(int[] aNums)
	{
		nums = aNums;
	}

	public Statistician()
	{
		nums = new int[]{};
	}

	public int sum()
	{
		int sum = 0;
		for (int each: getNums())
			sum += each;
		return sum;
	}

	public int count()
	{
		return getNums().length;
	}

	public int min()
	{
		int[] array = getNums();
		if (count() == 0) return -1;
		int min = array[0];
		for (int each: array)
			if (each < min)
				min = each;
		return min;
	}

	public int max()
	{
		int[] array = getNums();
		if (count() == 0) return -1;
		int max = array[0];
		for (int each: array)
			if (each > max)
				max = each;
		return max;
	}

	public int mean()
	{
		int[] array = getNums();
		if (count() == 0) return -1;
		double m = (double) sum() / count();
		return (int) Math.round(m);
	}

	public void addInput(int[] newInput)
	{
		int len1=this.nums.length, len2=newInput.length;
		int[] newArray = new int[len1 + len2];
		for (int i=0; i<len1; i++)
			newArray[i] = this.nums[i];
		for (int i=0; i<len2; i++)
			newArray[len1+i] = newInput[i];
		this.nums = newArray;
	}

	public static void main(String[] args)
	{
		int[] myNums = {30, 20, 40, 10};
		//myNums = new int[] {10, 1};
		Statistician stan = new Statistician(myNums);
		println("sum = " + stan.sum());
		println("count = " + stan.count());
		println("min = " + stan.min());
		println("max = " + stan.max());
		println("mean = " + stan.mean());
	}

	public static void println(Object o) { System.out.println(o.toString()); }

}