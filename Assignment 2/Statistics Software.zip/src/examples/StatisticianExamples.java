package examples;

//StatisticianExamples.java

/*
The purpose of this file is to demonstrate
the use of the class Statistician.

Overview:

You construct Statistician with an array of ints.

Statistician will do five statistical functions for you.

The example code below shows how to use Statistician.

*/

import java.util.Arrays;
import stats.Statistician;

public class StatisticianExamples
{

	//=================================================

	public static void main(String[] args)
	{
		println("\nWelcome to a demo of the Statistician class");
		demoBasicUse();
		demoAddingInputDynamically();
		println("\nThank you for taking time to view the demo. Goodbye...\n");
	}

	//=================================================

	public static void demoBasicUse() {

		println("\n-----------------------");
		println("Starting Demo: Basic Use\n");

		/*
		For the Statistician, here we demonstrate how to:

			1. Construct with given input
			3. Generate statistics using the
		*/

		//Declarations
		int[] myNums;
		int count, sum, min, max, mean;

		//Input
		myNums = new int[]{30, 20, 40, 10};

		//Construction
		Statistician stats = new Statistician(myNums);

		//Use
		sum = stats.sum();
		count = stats.count();
		min = stats.min();
		max = stats.max();
		mean = stats.mean();
		println("Input: " + Arrays.toString(myNums));
		println("Count: " + count);
		println("Sum: " + sum);
		println("Min: " + min);
		println("Max: " + max);
		println("Mean: " + mean);

	}

	//=================================================

	public static void demoAddingInputDynamically() {

		println("\n-----------------------");
		println("Starting Demo: Adding Input Dynamically\n");

		/*
		For the Statistician, here we demonstrate how to:

			1. Construct with no input
			2. Add subsets of input
			3. Generate statistics using the
		*/

		//Declarations
		int[] subset1, subset2;
		int count, sum, min, max, mean;

		//Input
		subset1 = new int[]{400, 100};
		subset2 = new int[]{200, 300};

		//Construction
		Statistician stats = new Statistician();

		//Use -- adding input dynamically
		stats.addInput(subset1);
		stats.addInput(subset2);

		//Use
		sum = stats.sum();
		count = stats.count();
		min = stats.min();
		max = stats.max();
		mean = stats.mean();
		println("Subset 1: " + Arrays.toString(subset1));
		println("Subset 2: " + Arrays.toString(subset2));
		println("Count: " + count);
		println("Sum: " + sum);
		println("Min: " + min);
		println("Max: " + max);
		println("Mean: " + mean);
	}

	//=================================================

	public static void println(Object o) { System.out.println(o.toString()); }

}