
import java.util.Arrays;
import java.util.List;

@SuppressWarnings("rawtypes") //Not using generics  
 
public class LinkedListTests extends SimpleTester {
	
	public static void main(String[] args) {
		LinkedListTests tester = new LinkedListTests();
		tester.runTests();
	}
		
	public void runTests() {
		
		/*Individual tests t1, t2 etc.
		By wrapping in Procedure (closure) we're able to do
		test pre and post (e.g. print results in a 
		general way -- in superclass' "runTest" method*/
		Procedure t1, t2, t3, t4, t5;
		t1  = () -> { this.testAddFirst(); };		
		t2  = () -> { this.testAddLast(); };
		t3  = () -> { this.testSize(); };		
		t4  = () -> { this.testRemoveFirst(); };		
		t5  = () -> { this.testRemoveLast(); };		
		this.runTest("testAddFirst", t1);
		this.runTest("testAddLast", t2);
		this.runTest("testSize", t3);		
		this.runTest("testRemoveFirst", t4);
		this.runTest("testRemoveLast", t5);		
		finish();
	}

	public void testAddFirst() {
		LinkedList ll = new LinkedList();
		List expected = sample2();
		addSample1FirstTo(ll);
		this.assertEquals(ll.asList(), expected);
	}
	
	public void testAddLast() {
		LinkedList ll = new LinkedList();
		List expected = sample1();
		addSample1LastTo(ll);
		this.assertEquals(ll.asList(), expected);		
	}
	
	public void testSize() {
		LinkedList ll = new LinkedList();
		List expected = sample1();
		addSample1LastTo(ll);
		this.assertEquals(expected.size(), ll.size());		
	}	
		
	public void testRemoveFirst() {
		LinkedList ll = new LinkedList();
		//Build list "sample1" (10, 20, 30, 40) in order
		//Then remove from from front (so should match "sample1"; i.e. be "in order")
		addSample1LastTo(ll);		
		List orderedList = sample1();
		int index = 0;
		while (!ll.isEmpty()) {
			Object actual, expected;
			expected = orderedList.get(index);
			actual = ll.removeFirst();
			String msg = format("removed index %d", index);
			this.assertEquals(msg, expected, actual);
			index++;			
		}
	}	
	
	public void testRemoveLast() {
		LinkedList ll = new LinkedList();
		//Build list "sample1" (10, 20, 30, 40) in order
		//Then remove from from end (so should match "sample2"; i.e. be "in reverse order")
		addSample1LastTo(ll);
		println("Size origional: " + ll.size());		
		List reversedList = sample2();
		int index = 0;

		while (!ll.isEmpty()) {
			Object actual, expected;
			expected = reversedList.get(index);
			actual = ll.removeLast();
			String msg = format("removed index %d", index);
			this.assertEquals(msg, expected, actual);
			index++;
		}
	}	
		
	protected static List sample1() {
		return Arrays.asList(new Integer[] {10, 20, 30, 40});
	}
	
	protected static List sample2() {
		return Arrays.asList(new Integer[] {40, 30, 20, 10});
	}	
	
	protected static List sampleSizeOne() {
		return Arrays.asList(new Integer[] {10});
	}	
	
	protected static void addSample1FirstTo(LinkedList ll) {
		for (Object each: sample1())
			ll.addFirst(each);
	}
	
	protected static void addSample1LastTo(LinkedList ll) {
		for (Object each: sample1())
			ll.addLast(each);
	}
	
	protected static void addSampleSizeOneTo(LinkedList ll) {
		for (Object each: sampleSizeOne())
			ll.addLast(each);
	}	
	
	
		

	
}
