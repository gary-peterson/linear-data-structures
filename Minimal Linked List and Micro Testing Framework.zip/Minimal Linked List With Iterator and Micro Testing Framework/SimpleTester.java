
public class SimpleTester {
	
	//===============================================================	
	//Ivars for Test statistics
	int count, failed, subCount, subFailed;
	String currentTestName;
	
	//===============================================================	
	//Running a Test	
	
	protected void runTest(String testName, Procedure p) {
		this.currentTestName = testName;
		this.preTest();
		try { p.evaluate(); }
		catch(Exception ex) { this.exceptionOccured(ex); }
		this.postTest();		
	}
	
	protected void preTest() {
		this.subCount = 0;
		this.subFailed = 0;
		printf("%nStarting test: %s%n", this.currentTestName);
	}
	
	protected void postTest() {
		int c, f;
		c = this.subCount;
		f = this.subFailed;
		if (f == 0)
			printf("PASSED -- %d of %d", c, c);
		else {
			int passedCount = c - f;
			println("#Tests: " + c);			
			println("FAILURES");
			println("#Passed: " + passedCount);
			println("#Failed: " + f);
		}

		println("");
	}	
	
	protected void exceptionOccured(Exception ex) {
		this.incrementCount();
		this.incrementFailed();
		println("EXCEPTION OCCURRED");
		if (ex.getCause() != null) {
			StackTraceElement err = ex.getCause().getStackTrace()[0];
			String exceptionDetails = String.format("\"%s\" (%s line %d)", err.getMethodName(),
										err.getFileName(), err.getLineNumber());
			println(exceptionDetails);
		}
		else
			ex.printStackTrace();
	}	
	
	//===============================================================	
	//Finishing	
	
	protected void finish() {
		printf("%n**** FINISHED TESTING ****%n");		
		println("**** TEST SUMMARY ****");
		int c, f, p;
		c = this.count;
		f = this.failed;
		p = c - f;
		println("Total #Tests: " + c);
		println("Total #Passed: " + p);
		println("Total #Failed: " + f);
		if (c > 0)
			printf("Percent Passing %d%%%n", Math.round(100.0 * p/c));
	}
	
	//===============================================================	
	//Test Tracking Helpers
	
	protected void incrementCount() {
		this.count++;
		this.subCount++;
	}
	
	protected void incrementFailed() {
		this.failed++;
		this.subFailed++;
	}	

	//===============================================================
	//Assert Helpers (e.g. the test "checks")
		
	protected void assertEquals(String msg, Object expected, Object actual) {
		this.incrementCount();
		boolean pass = actual.equals(expected);
		if (!pass) {
			this.incrementFailed();
			printf("FAILURE -- Actual %s -- Expected %s%n", actual.toString(), expected.toString());			
			if (!msg.isEmpty())
				println(msg);
		}
	}
	
	protected void assertEquals(Object expected, Object actual) {
		this.assertEquals("", expected, actual);
	}

	//===============================================================	
	//Printing Helpers
	
	protected static void println(Object o) {
		System.out.println(o.toString());
	}
	
	public static void printf(String template, Object... args) {
		System.out.printf(template, args);
	}	
	
	public static String format(String template, Object... args) {
		return String.format(template, args);
	}

}
