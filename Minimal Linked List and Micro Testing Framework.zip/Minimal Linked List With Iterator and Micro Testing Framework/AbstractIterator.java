
public abstract class AbstractIterator implements Iterator {

	abstract public boolean hasNext();
	abstract public void basicMoveToNext();
	abstract public Object basicPeek();

	public Object next() {
		Object nextData;
		if (!(hasNext()))
			return null;
		nextData = peek();
		moveToNext();
		return nextData;
	}
	
	public void moveToNext() {
		if (hasNext())
			basicMoveToNext();
	}
	
	public Object peek() {
		if (hasNext())
			return basicPeek();
		else
			return null;
	}
	

}