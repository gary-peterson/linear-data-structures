package interfaces;

import java.util.List;
@SuppressWarnings("all") //List is okay

public interface ListDs extends GeneralLinearDs, BiIterable {
	
	public void clear();

	public Object remove(Object data);

	public boolean contains(Object anElement);	//Return true if we find match (using "equals")
	
	//Adding
	public void addFirst(Object data);
	public void addLast(Object data);	
	public Object removeFirst();
	public Object removeLast();	
	public Object first();	
	public Object last();
}
