package interfaces;

public interface SpecializedLinearDs extends LinearDs {

}
