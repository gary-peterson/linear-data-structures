package interfaces;

public interface LinearDs extends DataStructure {

}
