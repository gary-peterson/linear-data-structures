package interfaces;

public interface GeneralLinearDs extends LinearDs {

}
