
package interfaces;

/*
	The idea of iterating in one direction.
	
	3/3/19 -- changed "as" to "to" in "toIterator"	
*/

public interface UniIterable
{
	public Iterator toIterator();
}


