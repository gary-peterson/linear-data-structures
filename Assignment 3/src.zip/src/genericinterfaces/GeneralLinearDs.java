package genericinterfaces;

public interface GeneralLinearDs<DT> extends LinearDs<DT> {

}
