package genericinterfaces;

import java.util.*;

//DT: Data Type (generics)

public interface IndexableList<DT> extends ListDs<DT>
{
	//Accessing
	public DT get(int index);
	public void set(int index, DT newElement);	//Replace element at index

	//Adding
	public void add(DT newElement);				//Add a new element to the end of the list -- e.g. at index = size()
	public void add(int index, DT newElement);	//Insert new elemement at pos	
	public void addAll(List<DT> newElements);			//Add new elements to end of list (in order received)

	//Removing
	public DT remove(int index);				//Remove element at index, return element.

	//Changing Order
	public void shuffle();							//Randomize order
	public void reverse();

	//Querying
	public int indexOf(DT anElement);	//Returns lowest index of matching element (using "equals"), or -1 if no matches
	
	public IndexableList<DT> copyFromTo(int startIndex, int stopIndex);
		/*e.g. if we have [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
		then copyFromTo(1, 3) we would return [20, 30, 40]*/

}


