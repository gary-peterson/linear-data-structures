
package genericinterfaces;

/*
	The idea of iterating in one direction.
	
	DT: Data Type (generics)		
*/

public interface UniIterable<DT>
{
	public Iterator<DT> toIterator();
}


