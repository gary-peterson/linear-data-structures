package genericinterfaces;

//DT: Data Type (generics)

public interface Stack<DT> extends SpecializedLinearDs<DT>  
{
	//Adding
	public void push(DT newElement);	//adds new top element

	//Getting
	public DT pop();	//removes top element
	public DT peek();	//returns top element (does not remove)
}




