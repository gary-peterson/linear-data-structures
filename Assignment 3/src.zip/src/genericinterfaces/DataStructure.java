package genericinterfaces;

import java.util.List;

public interface DataStructure<DT> extends UniIterable<DT> {
	
	public boolean isEmpty();	
	public int size();
	
	public List<DT> asList();
}
