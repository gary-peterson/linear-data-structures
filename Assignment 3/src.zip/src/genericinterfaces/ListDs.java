package genericinterfaces;

//DT: Data Type (generics)

public interface ListDs<DT> extends GeneralLinearDs<DT>, BiIterable<DT> {
	
	public void clear();

	public DT remove(DT data);

	public boolean contains(DT anElement);	//Return true if we find match (using "equals")
	
	//Adding
	public void addFirst(DT data);
	public void addLast(DT data);	
	public DT removeFirst();
	public DT removeLast();	
	public DT first();	
	public DT last();
}
