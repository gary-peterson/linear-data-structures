package genericinterfaces;

import java.util.List;

public interface Bag<DT> extends SpecializedLinearDs<DT>
{
	//Adding
	public void add(DT newElement);
	public void addAll(List<DT> newElements);

	//Getting
	public DT any();	//Returns any elment (or null for empty case)

	//Removing
	public DT remove(DT anElement);		//Remove any match (using "equals"), if match is found
	public void clear(); 	//Remove all elements

	//Querying
	public boolean contains(DT anElement);	//Return true if we find match (using "equals")
}





