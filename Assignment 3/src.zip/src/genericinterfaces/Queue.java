package genericinterfaces;

//DT: Data Type (generics)

public interface Queue<DT> extends SpecializedLinearDs<DT> 
{
	//Adding
	public void enqueue(DT newElement);		//add element to back/rear/tail

	//Getting
	public DT dequeue();	//remove and return (from front/head)
	public DT peek();		//peek (from front/head)

	//Displaying
	public void display();	//Show all elements using toString (sent to "each" element)
}





