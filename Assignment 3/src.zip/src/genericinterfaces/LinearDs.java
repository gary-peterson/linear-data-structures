package genericinterfaces;

public interface LinearDs<DT> extends DataStructure<DT> {

}
