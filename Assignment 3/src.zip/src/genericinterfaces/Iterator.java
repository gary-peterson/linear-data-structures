package genericinterfaces;

import java.util.List;

/*
next() -- return next data (may be null if hasNext is false), advance iterator to next
peek() -- return next data (may be null if hasNext is false)
hasNext() -- return true if iterator is not at end (has a next data)

Convenience methods 
	Note that these all work from the (current position (cp) in the iterator -- 
	e.g. generally you would use them with a "new" iterator (with cp at "start") 

	displayAll() -- display all elements (from current position)
	allEquals()-- return true if all elements in this iterator are equal to all in other. 
	toList() -- collect all data into a List and return it
	size() -- return size of iteration (from cp to end)

Note: displayAll, allEquals, toList, and size all assume the Iterator is at the start
		(the Iterator does NOT have to worry about resetting itself to start)

DT = Data Type (generics)
*/

public interface Iterator<DT>  
{
	//Basic
	public DT next();
	public DT peek();
	public boolean hasNext();
	
	//Convenience methods (especially for testing)
	public void displayAll();
	public boolean allEquals(Iterator<DT> other);
	public boolean allEquals(List<DT> other);	
	public List<DT> toList();
	public int size();		
}