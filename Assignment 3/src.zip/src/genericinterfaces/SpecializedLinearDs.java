package genericinterfaces;

public interface SpecializedLinearDs<DT> extends LinearDs<DT> {

}
