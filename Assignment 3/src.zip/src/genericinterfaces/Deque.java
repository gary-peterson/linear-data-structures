package genericinterfaces;

//DT: Data Type (generics)

public interface Deque<DT> extends SpecializedLinearDs<DT>, BiIterable<DT>
{
	//Adding
	public void addToFront(DT newElement);		//front or head
	public void addToBack(DT newElement);		//back or rear or tail

	//Getting
	public DT getFront();	//Return object at front (do not remove)
	public DT getBack();	//Return object at back (do not remove)

	//Removing
	public DT removeFront();	//Remove and return object at front
	public DT removeBack();		//Remove and return object at front
}



