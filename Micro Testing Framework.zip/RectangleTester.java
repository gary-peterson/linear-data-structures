import static java.lang.System.out;

public class RectangleTester extends AbstractTester {

	//----------------------------------------------------
	//Main (Simply Construct and Run)	

	public static void main(String[] args) {
		//All subclasses of AbstractTester will have a similar pattern for "main"
		RectangleTester tester = new RectangleTester();
		tester.run();
	}

	//----------------------------------------------------
	//Test Management

	@Override
	protected void runTests() {
		//Run our tests here
		test_accessing();
		test_computeArea();		
		test_computePerimeter();		
	}
	
	//----------------------------------------------------
	//Tests	

	public void test_accessing() {
		Rectangle rec;

		starting("test_accessing");
		
		rec = new Rectangle(10, 5);
		assertEquals("getWidth", rec.getWidth(), 10, rec);
		assertEquals("getWidth", rec.getHeight(), 5, rec);		
	}
	
	public void test_computeArea() {
		Rectangle rec;
		int actual, expected;
		
		starting("test_computeArea");		

		//Test zero case
		rec = new Rectangle(0, 0);
		expected = 0;
		actual = rec.computeArea();
		assertEquals("zero case", actual, expected, rec);
		
		//Test basic case
		rec = new Rectangle(10, 5);
		expected = 10 * 5;
		actual = rec.computeArea();
		assertEquals("basic case", actual, expected, rec);		
	}
	
	public void test_computePerimeter() {
		Rectangle rec;
		int actual, expected;
		
		starting("test_computePerimeter");		
		
		//Test zero case
		rec = new Rectangle(0, 0);
		expected = 0;
		actual = rec.computePerimeter();
		assertEquals("zero case", actual, expected, rec);
		
		//Test basic case
		rec = new Rectangle(10, 5);
		expected = 2 * (10 + 5);
		actual = rec.computePerimeter();
		assertEquals("basic case", actual, expected, rec);		
	}	

}
