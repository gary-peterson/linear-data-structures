/*
	Rectangle.java
	Last Modified: 5/19/19
*/

public class Rectangle {
	//=================================================================
	//Ivars

	private String description;
	private int width;
	private int height;

	//=================================================================
	//Construtors

	public Rectangle(String initialDescription, int initialWidth, int initialHeight) {

		this.description = initialDescription;
		this.width = initialWidth;
		this.height = initialHeight;
	}

	public Rectangle(int initialWidth, int initialHeight) {
		this("", initialWidth, initialHeight);
	}

	//=================================================================
	//Public Services (Methods)

	public int computeArea() {
		return this.width * this.height;
	}

	public int computePerimeter() {
		return (2 * this.width) + (2 * this.height);
	}

	public void tripleSize() {
		this.width = 3 * this.width;
		this.height = 3 * this.height;
	}

	public void factorWidthBy(int factor) {
		this.width = factor * this.width;
	}

	public void flipWidthAndHeight() {
		int oldHeight = this.height;
		this.height = this.width;
		this.width = oldHeight;
	}

	public String toString() {
		return "Rectangle -- " + this.description + " -- "
				+ "width=" + this.width + " height=" + this.height + " -- area="
				+ this.computeArea() + " Perimeter=" + this.computePerimeter();
	}

	//=================================================================
	//Accessors

	public void setWidth(int newWidth) {
		this.width = newWidth;
	}

	public void setHeight(int newHeight) {
		this.height = newHeight;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}



}
