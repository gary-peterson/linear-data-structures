
import static java.lang.System.out;

public class CarTester extends AbstractTester {
	
	//----------------------------------------------------
	//Main (Simply Construct and Run)	

	public static void main(String[] args) {
		//All subclasses of AbstractTester will have a similar pattern for "main"
		CarTester tester = new CarTester();
		tester.run();
	}

	//----------------------------------------------------
	//Test Management

	@Override
	protected void runTests() {
		//Run our tests here
		test_initalState();
		test_maxSafetyProblemScenario();
		test_oneSafetyProblemScenario();
		test_fixProblems();
	}
	
	//----------------------------------------------------
	//Tests	

	public void test_initalState() {
		Car car;
		boolean safe;

		starting("test_initalState");
		car = new Car();
		car.go();
		safe = car.isSafe();
		assertEquals("initial state using empty constructor", safe, false, car);

		car = new Car(false, true, false);
		car.go();
		safe = car.isSafe();
		assertEquals("initial state using three-parameter constructor", safe, true, car);
	}

	//----------------------------------------------------	

	public void test_maxSafetyProblemScenario() {
		Car car;
		boolean safe;
		int problemCount;

		starting("test_maxSafetyProblemScenario");
		car = new Car();
		car.setSeatbelt(false);
		car.setDoorsOpen(true);
		car.go();
		safe = car.isSafe();
		assertEquals("two problems - 1", safe, false, car);
		problemCount = car.getSafetyProblems();
		assertEquals("two problems - 2", problemCount, 2, car);
	}

	//----------------------------------------------------

	public void test_oneSafetyProblemScenario() {
		Car car;
		boolean safe;
		int problemCount;
		String msg;

		starting("test_oneSafetyProblemScenario");

		//seatbelt
		car = new Car(false, true, false); //construct as initially safe
		car.setSeatbelt(false); //one problem
		car.go();
		safe = car.isSafe();
		msg = "seatbelt off";
		assertEquals(msg + " - 1", safe, false, car);
		problemCount = car.getSafetyProblems();
		assertEquals(msg + " - 2", problemCount, 1, car);

		//doors open
		car = new Car(false, true, false); //construct as initially safe
		car.setDoorsOpen(true); //one problem
		car.go();
		safe = car.isSafe();
		msg = "doors open";
		assertEquals(msg + " - 1", safe, false, car);
		problemCount = car.getSafetyProblems();
		assertEquals(msg + " - 2", problemCount, 1, car);

		//Close doors to fix problem
		car.setDoorsOpen(false);
		safe = car.isSafe();
		msg = "closed doors";
		assertEquals(msg + " - 1", safe, true, car);
		problemCount = car.getSafetyProblems();
		assertEquals(msg + " - 2", problemCount, 0, car);
	}

	//----------------------------------------------------	

	public void test_fixProblems() {
		Car car;
		boolean safe;
		int problemCount;
		String msg;

		starting("test_fixProblems");

		car = new Car();
		car.setSeatbelt(false);
		car.setDoorsOpen(true);
		car.go();
		safe = car.isSafe();
		msg = "two problems";
		assertEquals(msg + " - 1", safe, false, car);
		problemCount = car.getSafetyProblems();
		assertEquals(msg + " - 2", problemCount, 2, car);

		//Fix
		car.fixProblems();
		safe = car.isSafe();
		assertEquals("isSafe", safe, true, car);
		problemCount = car.getSafetyProblems();
		assertEquals("problem count", problemCount, 0, car);
	}

	//----------------------------------------------------


}
