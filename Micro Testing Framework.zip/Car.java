

public class Car {
	
	private boolean moving;
	private boolean seatbelt;
	private boolean doorsOpen;
	private int safetyProblems;

	public Car() {
		reset();
	}
	
	public Car(boolean moving, boolean seatbelt, boolean doorsOpen) {
		this.moving = moving;
		this.seatbelt = seatbelt;
		this.doorsOpen = doorsOpen;
	}

	@Override
	public String toString() {
		return "Car -- Moving, Seatbelt, DoorsOpen -- "
				+ moving + " " + seatbelt + " " + doorsOpen;
	}
	
	//==============================================

	public void go() {
		this.moving = true;
		//this.moving = false;
	}
	
	public void stop() {
		this.moving = false;
	}
	
	//==============================================	

	public int getSafetyProblems() {
		return safetyProblems;
	}

	public void setSeatbelt(boolean seatbelt) {
		this.seatbelt = seatbelt;
	}

	public void setDoorsOpen(boolean doorsOpen) {
		this.doorsOpen = doorsOpen;
	}	
	
	//==============================================
	
	public void runSafetyCheck() {
		int count = 0;
		if (moving) {
			if (!seatbelt) ++count;
			if (doorsOpen) ++count;
		}
		safetyProblems = count;
	}

	public boolean isSafe() {
		runSafetyCheck();
		return this.safetyProblems == 0;
	}
	
	public void fixProblems() {
		if (!this.seatbelt) seatbelt=true;
		if (this.doorsOpen) doorsOpen=false;		
	}	

	public void reset() {
		this.moving = false;
		this.seatbelt = false;
		this.doorsOpen = true;
		this.safetyProblems = 0;
	}	
	
	//==============================================	

}
