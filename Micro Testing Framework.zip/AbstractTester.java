import static java.lang.System.out;

public abstract class AbstractTester {
	
	//----------------------------------------------------
	//ivars

	int failures;
	int count;
	
	//----------------------------------------------------
	//Public Method(s)
	
	public void run() {
		reset();
		runTests();
		finish();
	}
	
	//----------------------------------------------------
	//Abstract Methods (must be implemented by subclasses)	
	
	protected abstract void runTests();
	
	//----------------------------------------------------
	//Helper Methods (for subclasses)
	
	protected void starting(String label) {
		out.println("----------");
		out.printf("Starting: %s %n%n", label);
	}
	
	//----------------------------------------------------
	//Helper Methods -- Asserts
	
	protected void assertEquals(String aMsg, Object actual, Object expected, Object subject) {
		boolean passed; 
		passed = equalsSafely(actual, expected);	//allow nulls
		//passed = actual.equals(expected);		
		String msg = passed ? "passed" : "FAILED";
		if (aMsg != null)
			msg += String.format(" (%s)", aMsg);
		out.println(msg);
		if (!passed && (subject != null))
			out.printf("Tested Object: %s%n", subject.toString());
		if (!passed) {
			out.printf("Expected: %s%n", expected);
			out.printf("Actual: %s%n%n", actual);
			this.failures++;
		}
		if (passed)	//Line for formatting 
			out.println("");
		this.count++;
	}
	
	protected void assertEquals(String aMsg, Object actual, Object expected) {
		assertEquals(aMsg, actual, expected, null);
	}
	
	protected void assertEquals(Object actual, Object expected) {
		assertEquals(null, actual, expected, null);
	}	

	//----------------------------------------------------
	//Initializing
	
	protected void reset() {
		this.count = 0;		
		this.failures = 0;
	}
	
	//----------------------------------------------------
	//Finishing and Summarizing	
	
	protected void finish() {
		printSummary();
	}
	
	protected void printSummary() {
		int n, f, p, percentPassing=0;
		boolean allPassed;
		n = this.count;
		f = this.failures;
		p = n - f;
		allPassed = f == 0;
		if (n > 0)
			percentPassing = (int)Math.round((100.0 * p) / n);
		out.printf("-------------------%n", this.getClass().getSimpleName());			
		out.printf("TEST SUMMARY for %s%n%n", this.getClass().getSimpleName());
		out.printf("Total # Tests: %d%n", n);		
		out.printf("Failed: %d of %d%n", f, n);
		out.printf("Passed: %d of %d (%d%%)%n", p, n, percentPassing);		
		out.printf("Overall: %s%n", (allPassed ? "PASSED" : "FAILED")); 
	}		

	//Helpers, General Purpose

	public boolean equalsSafely(Object actual, Object expected) {
		/*We add "null-guarding" here, e.g. we handle:
			two nulls (return true)
			one null (return false)
		*/	
		//If ONLY one is null, return false
		if ((actual==null) ^ (expected==null))
			return false;
		//If both null, return true
		if (actual==null && expected==null)
			return true;
		//Neither are null, we can safely use "equals"
		return actual.equals(expected);
	}

}
